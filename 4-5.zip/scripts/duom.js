export default class Salys{
  constructor({valiuta, linkas, populiacija, zemynas, salis, religion, dImage, id, karalyste}){
    this.salis = salis;
    this.zemynas = zemynas;
    this.populiacija = populiacija;
    this.valiuta = valiuta;
    this.religion = religion;
    this.dImage = dImage;
    this.id = id;
    this.karalyste = karalyste;
    this.linkas= linkas;
    
    return this.render();
  }
  render(){
    this.divCard = document.createElement('div');
    this.divCard.classList.add('card');

    this.heading = document.createElement('h1');
    this.headingText = document.createTextNode(`${this.salis} - ${this.zemynas}`);
    this.heading.appendChild(this.headingText);
    // class: ['raudonasTekstas', 'centruotasTekstas']

    this.image = document.createElement('img');
    this.image.setAttribute('src', this.dImage);
    // this.image.setAttribute('alt', 'profile photo');

    this.valPar = document.createElement('p');
    this.valParText = document.createTextNode(`Valiuta: ${this.valiuta}`);
    this.valPar.appendChild(this.valParText);

    this.relPar = document.createElement('p');
    this.relParText = document.createTextNode(`religion: ${this.religion}`);
    this.relPar.appendChild(this.relParText);

    this.popPar = document.createElement('p');
    this.popParText = document.createTextNode(`Populiacija: ${this.populiacija} mln`);
    this.popPar.appendChild(this.popParText);

    this.linko = document.createElement('span');
    this.linkoUrl = document.createTextNode(`explore more: ${this.linkas}`);
    this.linko.appendChild(this.linkoUrl);

    this.karun = document.createElement('i');
    this.karunText = document.createTextNode(`${this.karuna()}`);
    this.karun.appendChild(this.karunText);

    // this.icon = document.createElement('i');
    // this.icon.setAttribute('./', this.karuna());

    this.deleteButton = document.createElement('button');
    this.deleteButtonText = document.createTextNode('panaikinti');
    this.deleteButton.appendChild(this.deleteButtonText);
    this.delete();



    this.divCard.append(this.heading, this.image, this.popPar, this.valPar, this.relPar, this.linko, this.deleteButton);

    return this.divCard;
  }
  karuna(){
    if(this.karalyste === true){
      return 'monarchy';
    } else(this.karalyste === false)
      return 'demokratija';
    // kodėl nepriima braketų?
  }

  delete(){
    this.deleteButton.addEventListener('click', () => {
      this.divCard.remove();
      fetch(`http://localhost:3000/zmones/${this.id}`, { 
        method: "DELETE"
      });
    });
  }}





















